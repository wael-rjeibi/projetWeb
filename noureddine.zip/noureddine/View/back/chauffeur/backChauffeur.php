<?php
include_once '../../../Model/chauffeur.php';
include_once '../../../Controller/chauffeurC.php';
include_once '../../../Controller/voitureC.php';
$chauffeurC = new chauffeurC();
$voiturec=new voitureC();
$listeC = $chauffeurC->afficherChauffeur();
$listev=$voiturec->afficherVoiture();

$chauffeurC = new chauffeurC();
if (
    isset($_POST["nom"]) && 
    isset($_POST["email"]) &&
    isset($_POST["idv"]) &&
    isset($_POST["numtel"]) && 
    isset($_POST["adresse"]) &&
    isset($_POST["image"])
) {
    if (
        !empty($_POST["nom"]) && 
        !empty($_POST["email"]) &&
        !empty($_POST["idv"]) &&
        !empty($_POST["numtel"]) && 
        !empty($_POST["adresse"]) &&
        !empty($_POST["image"])
    ) {
        $chauffeur = new chauffeur(
          $_POST['idv'],
            $_POST['nom'],
            $_POST['email'],
            $_POST['numtel'],
            $_POST['adresse'],
            $_POST['image']
        );
        if(strlen($_POST['numtel'])!=8){
          echo "<script>alert('Numero de telephone doit etre sur 8 chiffres veuillez ressayer...')</script>";
        }
        else{
        $chauffeurC->ajouterChauffeur($chauffeur);
        
        header('Location:backChauffeur.php');}}
        
    else
        $error = "Missing information";
}
if(isset($_POST['submit'])){
	$listeC= $chauffeurC->rechercherUsers($_POST['search']);
    
}
if((!isset($_POST['search'])) || $_POST['search']==""){
    $listeC = $chauffeurC->afficherChauffeur();
}
if (isset($_POST["tri"])) {
  if(!empty($_POST["tri"]))
  $listeC = $chauffeurC->afficherChauffeurTrie( $_POST['tri']);
}

?>


<link rel="stylesheet" href="style.css" type="text/css" media="all" />

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>SpringTime</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />


</head>
<script src="js/saisie.js"></script>

<body>
<!--<link rel="stylesheet" href="css3/style.css" type="text/css" media="all" />-->
<!-- Header -->
<div id="header">
  <div class="shell">
    <!-- Logo + Top Nav -->
    <div id="top">
      <h1><a href="#">Waselny</a></h1>
      <div id="top-navigation"> </a> </span> <a href="logout.php">Log out</a> </div>
      <form action="" method="POST" class="search-form">
                <input type="text" name="search" id="search" placeholder="search" style="background:#1fe0ff;">
					<button type="submit" class="searchButton" name="submit">search</button>
				</form>
    </div>
    <!-- End Logo + Top Nav -->
    <!-- Main Nav -->
    <div id="navigation">
    <ul>
        <li><a href="../../backClients.php" class="active"><span>Gestion Clients</span></a></li>
       
        <li><a href="../../backDiagnostic.php" class="active"><span>Gestion diagnostics</span></a></li>
        <li><a href="../../listMap.php" class="active"><span>Gestion maps</span></a></li>

        <li><a href="backChauffeur.php" class="active"><span>Gestion Chauffeurs</span></a></li>
        <li><a href="backVoiture.php" class="active"><span>Gestion voitures</span></a></li>

        <li><a href="../backTraget.php" class="active"><span>Gestion tragets</span></a></li>
        <li><a href="../backProposition.php" class="active"><span>Gestion propositions</span></a></li>
      
      </ul>
    </div>
    <!-- End Main Nav -->
  </div>
</div>
<!-- End Header -->
<!-- Container -->
<div id="container">
  <div class="shell">
    <!-- Small Nav -->
    <div class="small-nav"> <a href="#">chauffeur</a> <span>&gt;</span> voiture </div>
    <!-- End Small Nav -->
    <!-- Message OK -->
    
    <!-- End Message OK -->
    <!-- Message Error -->
    
    <!-- End Message Error -->
    <br />
    <!-- Main -->
    <div id="main">
      <div class="cl">&nbsp;</div>
      <!-- Content -->
      <div id="content">
        <!-- Box -->
       
          <!-- Box Head -->
          <div class="box-head">
            <h2 class="left">inscription chauffeur</h2>
            <div class="right">
            
            </div>
          </div>
          
          <!-- End Box Head -->
          <!-- Table -->
          <div class="table">
          
            <table width="100%" border="0" cellspacing="0" cellpadding="0" >
        
              <tr>
               
                <th>ID</th>
                <th>IDV</th>
                <th>Nom</th>
            
                <th>Email</th>
                <th>Numtel</th>
            
            <th>Adresse</th>
            <th>Image</th>
              
               
              </tr>

              

              <?php
    foreach($listeC as $chauffeur){
        ?>


              <tr>
                <td><?php echo $chauffeur['id']; ?></td>
                <td><?php echo $chauffeur['idv']; ?></td>
                <td><?php echo $chauffeur['nom']; ?></td>
                 
                <td><?php echo $chauffeur['email']; ?></td>
                <td><?php echo $chauffeur['numtel']; ?></td>  
                <td><form action="map1.php" method="POST">
                              <input class="btn btn-danger" type="submit" name="submit1" value="<?php echo $chauffeur['adresse']; ?>">
                              <input type="hidden" name="adresse" value="<?=$chauffeur['adresse']?>">
                          </form>
                        </td>
                <td><img  src="../../front/chauffeurs/images/<?php echo $chauffeur['image']; ?>"width="50" height="60">
</td>
               
                <td><a href="supprimerChauffeur.php?id=<?php echo $chauffeur['id']; ?>" class="ico del">Delete</a> </td>
                <td> <a href="modifierChauffeur.php?id=<?php echo $chauffeur['id']; ?>" class="ico edit">Edit</a>
               
              
              
              
              </td>
              </tr>
              <?php } ?>
              
              
              
              
              
              
            
           
            </table>
            <!-- End Pagging -->
          </div>
          <!-- Table -->
      
        <!-- End Box -->
        <!-- Box -->
        <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>Add New chauffeur</h2>
          </div>
          
          <!-- End Box Head -->
          <form action="#" method="post">
            <!-- Form -->
            <div class="form">
              <p> 
                <label>Nom </label>
                <input type="text" class="field size1" name="nom" id="nom"/>
              </p>
              <p> 
                <label>idv </label>
                <select name="idv" type="number" placeholder="">
				
                <?php foreach($listev as $voiture){ ?>
												<option value="<?php echo $voiture['idv']; ?>"><?php echo $voiture['idv']; ?> </option>
												<?php } ?>
											</select><p id="idv" class="error"></p>
                      
              </p>

              <p> 
                <label>Email </label>
                <input type="email" class="field size1" name="email" id="email" />
              </p>
              

              <p> 
                <label>Numtel </label>
                <input type="number" class="field size1" name="numtel" id="numtel" />
              </p>
              <p> 
                <label>Adresse </label>
                <input type="texte" class="field size1" name="adresse" id="adresse" />
              </p>
              <p> 
                <label>Image </label>
                <input type="file" class="field size1" name="image" id="image" />
              </p>
            </div>
            <!-- End Form -->
            <!-- Form Buttons -->
            <div class="buttons">
              <input type="Reset" class="button" value="Reset" />
              <input type="submit" class="button" value="submit" onclick="verif();"/>
            </div>
            <!-- End Form Buttons -->
          </form>
        </div>
        <!-- End Box -->
      </div>
      <!-- End Content -->
      <!-- Sidebar -->
      <div id="sidebar">
        <!-- Box -->
        <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>chauffeurr</h2>
          </div>
          <!-- End Box Head-->
          <div class="box-content"> <a href="#" class="add-button"><span>Add new chauffeurr</span></a>
            <div class="cl">&nbsp;</div>
            <p class="select-all">
             
            <div class="sort">
              <form method="POST"><label>Sort by</label>
              <select name="tri" class="field" >
              <option value="email">email</option>
              <option value="numtel">numtel</option>
              <option value="nom">nom</option>
                
              </select><input type="submit"  value="trier"></form>
              
            </div>
            </p>
            
           
          </div>
        </div>

      
        <!-- End Box -->
      </div>
      <!-- End Sidebar -->
      <div class="cl">&nbsp;</div>
    </div>
    <div id="piechart"> </div>
    <!-- Main -->
  </div>
</div>



<?php 
include_once "../../../Controller/chauffeurC.php";
$chauffeurC = new chauffeurC();

$listeC = $chauffeurC->statistiques();
 ?>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
    
  var data = google.visualization.arrayToDataTable([
   
  [ 'adresse', 'nom'],
  

  <?php
 
 foreach($listeC as $k){
  echo "["; echo "'";echo $k['adresse'];echo"'";echo",";echo $k['count(*)'];echo"],";}?>


 

 
]);

 // Optional; add a title and set the width and height of the chart
 var options = {'title':'ADRESSE', 'width':750, 'height':400};

 var chart = new google.visualization.PieChart(document.getElementById('piechart'));
 chart.draw(data, options);
}
</script>


<!-- End Container -->
<!-- Footer -->
<div id="footer">
  <div class="shell"> <span class="left">&copy; 2010 - CompanyName</span> <span class="right"> Design by <a href="http://chocotemplates.com">Chocotemplates.com</a> </span> </div>
</div>
<!-- End Footer -->

</body>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit
"></script>
<div id="google_translate_element"></div>
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
    }
</script>
</html>
