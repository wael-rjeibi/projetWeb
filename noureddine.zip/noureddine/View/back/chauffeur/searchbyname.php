<?php
require_once "../../../Controller/chauffeurC.php";

$listeC = new chauffeurC();

if(isset($_POST['searchButton']) && isset($_POST['search'])){
	$listeC= $chauffeurC->rechercherUsers($_POST['search']);
	unset($_POST['search']);
	var_dump($listeC);
}
?>