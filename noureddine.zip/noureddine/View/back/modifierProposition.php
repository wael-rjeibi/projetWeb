<link rel="stylesheet" href="style.css" type="text/css" media="all" />
<?php
 include_once '../../Controller/propositionC.php';
 
 $co = new propositionC();
 if(isset($_GET['id'])){
   $propositionC = new propositionC();
   $listeC = $propositionC->afficherPropositionDetail($_GET['id']);
 
 foreach($listeC as $pro){
 ?>
 <body>
<!--<link rel="stylesheet" href="css3/style.css" type="text/css" media="all" />-->


  <div class="shell">
    <!-- Logo + Top Nav -->
    <div id="top">
      <h1><a href="#">Antico</a></h1>
  </div>
   <form action="" method="post">
   <!-- Box -->
   <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>Add New Event</h2>
          </div>
          <!-- End Box Head -->
            <!-- Form -->
            <div class="form">
              <p> 
                <label>Nom </label>
                <input type="text" class="field size1" name="nom" value="<?php echo $pro['nom'];?>" />
              </p>
            
              <p> 
                <label>Pourcentage </label>
                <input type="number" class="field size1" name="pourcentage" value="<?php echo $pro['pourcentage'];}?>" />
              </p>

             

             
            </div>
            <!-- End Form -->
            <!-- Form Buttons -->
            <div class="buttons">
              <input type="Reset" class="button" value="Reset" />
              <input type="submit" class="button" value="submit" />
            </div>
            <!-- End Form Buttons -->
          </form>
 </div>
 </div>
 <?php
 // create event
 $proposition = null;

 // create an instance of the controller

 $propositionC = new propositionC();
 if (
     isset($_POST["nom"]) && 
      isset($_POST["pourcentage"]) 
 ) {
     if (
         !empty($_POST["nom"]) && 
         !empty($_POST["pourcentage"])  
     ) {
         $proposition = new proposition(
             $_POST['nom'],
             $_POST['pourcentage']
         );
        $propositionC->modifierProposition($_GET['id'],$proposition);
         
         header('Location:backProposition.php');
     }
     else
         $error = "Missing information";
 }

 
}

?>