<?php
 include_once '../../Controller/tragetC.php';
 $co = new tragetC();
 if(isset($_GET['id'])){
     $co->supprimerTraget($_GET['id']);
 
    header('Location:backTraget.php');
    }

 ?>