<?php
class diagnostic{
    private ?int $id = null;
    private ?int $idVoiture = null;
    private ?string $responsable = null;
    private ?string $dateD = null;
    function __construct(int $idVoiture,string $responsable,string $dateD)
    {
        
        $this->idVoiture=$idVoiture;
        $this->responsable=$responsable;
        $this->dateD=$dateD;
    }
    function getId(): int{
        return $this->id;
    }
    function getIdVoiture(): int{
        return $this->idVoiture;
    }
   
    function getResponsable(): string{
        return $this->responsable;
    }
    
    function getDateD(): string{
        return $this->dateD;
    }
    function setIdVoiture(int $idVoiture): void{
        $this->idVoiture=$idVoiture;
    }
    
    function setResponsable(string $responsable): void{
        $this->responsable=$responsable;
    }
    function setDateD(string $dateD): void{
        $this->dateD=$dateD;
    }
   
}
?>