<?php
class chauffeur{
    private ?int $id = null;
    private ?int $idv = null;
    private ?string $nom = null;
    private ?string $email = null;
    private ?int $numtel = null;
    private ?string $adresse = null;
    private ?string $image = null;
    function __construct(int $idv,string $nom,string $email,int $numtel,string $adresse,string $image)
    {
        $this->idv=$idv;
        $this->nom=$nom;
        $this->email=$email;
        $this->numtel=$numtel;
        $this->adresse=$adresse;
        $this->image=$image;
    }
    function getId(): int{
        return $this->id;
    }
    function getidv(): int{
        return $this->idv;
    }
    function getNom(): string{
        return $this->nom;
    }
   
    function getEmail(): string{
        return $this->email;
    }
    
    function getNumtel(): string{
        return $this->numtel;
    }
    function getAdresse(): string{
        return $this->adresse;
    }
    function getImage(): string{
        return $this->image;
    }
    function setidv(string $idv): void{
        $this->idv=$idv;
    }
    function setNom(string $nom): void{
        $this->nom=$nom;
    }
    
    function setEmail(string $email): void{
        $this->email=$email;
    }
    function setNumtel(string $numtel): void{
        $this->numtel=$numtel;
    }
   
    
    
}
?>