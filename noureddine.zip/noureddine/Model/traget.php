<?php
class traget{
    private ?int $ref = null;
    private ?string $libelle = null;
    private ?string $depart = null;
    private ?string $destination = null;
    private ?float $temps = null;
    function __construct(string $libelle,string $depart,string $destination,float $temps)
    {
        
        $this->libelle=$libelle;
        $this->depart=$depart;
        $this->destination=$destination;
        $this->temps=$temps;
    }
    function getRef(): int{
        return $this->ref;
    }
    function getLibelle(): string{
        return $this->libelle;
    }
   
    function getDepart(): string{
        return $this->depart;
    }
    function getDestination(): string{
        return $this->destination;
    }
    
    function getTemps(): float{
        return $this->temps;
    }
    function setLibelle(string $libelle): void{
        $this->libelle=$libelle;
    }
    function setDepart(string $depart): void{
        $this->depart=$depart;
    }
    function setDestination(string $destination): void{
        $this->destination=$destination;
    }

    function setTemps(float $temps): void{
        $this->temps=$temps;
    }
  
 
   
}
?>