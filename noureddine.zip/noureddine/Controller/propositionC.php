<?php
include_once("C:/xampp/htdocs/noureddine/config.php");
include_once("C:/xampp/htdocs/noureddine/Model/proposition.php");
class propositionC
{
   
    function afficherProposition(){
        $sql="select * from Proposition";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
    }
    catch(Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
}


public function ajouterProposition($Proposition){
    $sql="insert into Proposition(nom,pourcentage) values(:nom,:pourcentage)";
    $db = config::getConnexion();
    try{
        $query=$db->prepare($sql);
        $query->execute([
        'nom'=>$Proposition->getNom(),
        'pourcentage'=>$Proposition->getPourcentage()
        
        ]);
        
    }
        catch(Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
}



function modifierProposition($ref,$Proposition) {
    $sql="UPDATE  Proposition set nom=:nom,pourcentage=:pourcentage where ref=".$ref."";
    $db = config::getConnexion();
    try{
        $query = $db->prepare($sql);
    
        $query->execute([
            'nom'=>$Proposition->getNom(),
            'pourcentage'=>$Proposition->getPourcentage()
            
        ]);			
    }
    catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }		
  }
public function afficherPropositionDetail(int $rech1)
    {
        $sql="select * from Proposition where ref=".$rech1."";
        
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function supprimerProposition($ref)
    {
        $sql = "DELETE FROM Proposition WHERE ref=".$ref;
        $db = config::getConnexion();
        $query =$db->prepare($sql);
        
        try {
            $query->execute();
        }
        catch(Exception $e){
            die('Erreur: '.$e->getMessage());
    
        }
    }

}

?>