<?php
include_once "C:/xampp/htdocs/noureddine/config.php";
include_once "C:/xampp/htdocs/noureddine/Model/chauffeur.php";
class chauffeurC
{
    public function statistiques()
{
  
  $sql="select adresse,count(*) from chauffeur group by adresse";
    
    $db = config::getConnexion();
    try{
        $liste = $db->query($sql);
        return $liste;
    }
    catch(Exception $e){
        die('Erreur: '.$e->getMessage());
    }
}
   


   

    function afficherChauffeur(){
        $sql="select * from chauffeur";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
    }
    catch(Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
}

function afficherChauffeurTrie($adresse){
    $sql="select * from chauffeur order by ".$adresse;
    $db = config::getConnexion();
    try{
        $liste = $db->query($sql);
        return $liste;
}
catch(Exception $e){
    echo 'Erreur: '.$e->getMessage();
}
}

public function ajouterChauffeur($chauffeur){
    $sql="insert into chauffeur(idv,nom,email,numtel,adresse,image) values(:idv,:nom,:email,:numtel,:adresse,:image)";
    $db = config::getConnexion();
    try{
        $query=$db->prepare($sql);
        $query->execute([
        'idv' => $chauffeur->getidv(),
        'nom'=>$chauffeur->getNom(),
        'email'=>$chauffeur->getEmail(),
        'numtel'=>$chauffeur->getNumtel(),
        'image'=>$chauffeur->getImage(),
        'adresse'=>$chauffeur->getAdresse()
        ]);
        
    }
        catch(Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
}




function modifierChauffeur($id,$chauffeur) {
    $sql="UPDATE  chauffeur set idv=:idv,nom=:nom,numtel=:numtel,email=:email,image=:image,adresse=:adresse where id=".$id."";
    $db = config::getConnexion();
    try{
        $query = $db->prepare($sql);
    
        $query->execute([
            'idv' => $chauffeur->getidv(),
            'nom' => $chauffeur->getNom(),
            'numtel' => $chauffeur->getNumtel(),
            'email' => $chauffeur->getEmail(),
            'adresse' => $chauffeur->getAdresse(),
            'image' => $chauffeur->getImage()
        ]);			
    }
    catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }		
  }
public function afficherChauffeurDetail(int $rech1)
    {
        $sql="select * from chauffeur where id=".$rech1."";
        
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
public function supprimerChauffeur($id)
{
    $sql = "DELETE FROM chauffeur WHERE id=".$id."";
    $db = config::getConnexion();
    $query =$db->prepare($sql);
    
    try {
        $query->execute();
    }
    catch(Exception $e){
        die('Erreur: '.$e->getMessage());

    }
}
function rechercherUsers($nom)
    {        
                 $sql="SELECT * FROM chauffeur WHERE nom LIKE '".$nom."%'";
                 $db = config::getConnexion();

               	try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	


    }
}

?>