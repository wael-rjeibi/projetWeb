<?php
include_once("C:/xampp/htdocs/noureddine/config.php");
include_once("C:/xampp/htdocs/noureddine/Model/map.php");

class mapC
{
    function afficherMap(){
        $sql="select * from map";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
    }
    catch(Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
}

public function ajouterMap($map){
    $sql="insert into map(lien,nom) values(:lien,:nom)";
    $db = config::getConnexion();
    try{
        $query=$db->prepare($sql);
        $query->execute([
        'lien'=>$map->getLien(),
        'nom'=>$map->getNom()
        ]);
        
    }
        catch(Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
}





}

?>