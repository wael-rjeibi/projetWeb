<?php
 include_once '../Controller/diagnosticC.php';
 $co = new diagnosticC();
 if(isset($_GET['id'])){
     $co->supprimerDiagnostic($_GET['id']);
 
    header('Location:backDiagnostic.php');
    }

 ?>