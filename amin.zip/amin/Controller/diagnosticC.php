<?php
include_once("C:/xampp/htdocs/amin/config.php");
include_once("C:/xampp/htdocs/amin/Model/diagnostic.php");

class diagnosticC
{
    function afficherDiagnostic(){
        $sql="select * from diagnostic";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
    }
    catch(Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
}
function afficherDiagnosticTri($critere){
    $sql="select * from diagnostic order by $critere";
    $db = config::getConnexion();
    try{
        $liste = $db->query($sql);
        return $liste;
}
catch(Exception $e){
    echo 'Erreur: '.$e->getMessage();
}
}
function afficherDiagnosticRech($critere,$rech){
    $sql="select * from diagnostic where $critere like '$rech%'";
    $db = config::getConnexion();
    try{
        $liste = $db->query($sql);
        return $liste;
}
catch(Exception $e){
    echo 'Erreur: '.$e->getMessage();
}
}

public function ajouterDiagnostic($diagnostic){
    $sql="insert into diagnostic(idVoiture,responsable,dateD) values(:idVoiture,:responsable,:dateD)";
    $db = config::getConnexion();
    try{
        $query=$db->prepare($sql);
        $query->execute([
        'idVoiture'=>$diagnostic->getIdVoiture(),
        'responsable'=>$diagnostic->getResponsable(),
        'dateD'=>$diagnostic->getDateD()
        ]);
        
    }
        catch(Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
}



function modifierDiagnostic($id,$diagnostic) {
    $sql="UPDATE  diagnostic set idVoiture=:idVoiture,responsable=:responsable,dateD=:dateD where id=".$id."";
    $db = config::getConnexion();
    try{
        $query = $db->prepare($sql);
    
        $query->execute([
            'idVoiture' => $diagnostic->getIdVoiture(),
            'responsable' => $diagnostic->getResponsable(),
            'dateD' => $diagnostic->getDateD()
        ]);			
    }
    catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }		
  }
public function afficherDiagnosticDetail(int $rech1)
    {
        $sql="select * from diagnostic where id=".$rech1."";
        
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
public function supprimerDiagnostic($id)
{
    $sql = "DELETE FROM diagnostic WHERE id=".$id."";
    $db = config::getConnexion();
    $query =$db->prepare($sql);
    
    try {
        $query->execute();
    }
    catch(Exception $e){
        die('Erreur: '.$e->getMessage());

    }
}

}

?>