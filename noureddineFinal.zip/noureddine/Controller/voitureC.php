<?php
include_once "C:/xampp/htdocs/noureddine/config.php";
include_once "C:/xampp/htdocs/noureddine/Model/chauffeur.php";
class voitureC
{
   

    function afficherVoiture(){
        $sql="select * from voiture";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
    }
    catch(Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
}

public function ajouterVoiture($voiture){
    $sql="insert into voiture(marque,matricule,image) values(:marque,:matricule,:image)";
    $db = config::getConnexion();
    try{
        $query=$db->prepare($sql);
        $query->execute([
        'marque'=>$voiture->getMarque(),
        'matricule'=>$voiture->getMatricule(),
        'image'=>$voiture->getImage()
        
        ]);
        
    }
        catch(Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
}




function modifierVoiture($idv,$voiture) {
    $sql="UPDATE  voiture set marque=:marque,matricule=:matricule,image=:image where idv=".$idv."";
    $db = config::getConnexion();
    try{
        $query = $db->prepare($sql);
    
        $query->execute([
            'marque' => $voiture->getMarque(),
            'matricule' => $voiture->getMatricule(),  
            'image' => $voiture->getImage()
        ]);			
    }
    catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }		
  }
public function afficherVoitureDetail(int $rech1)
    {
        $sql="select * from Voiture where idv=".$rech1."";
        
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
public function supprimerVoiture($idv)
{
    $sql = "DELETE FROM voiture WHERE idv=".$idv."";
    $db = config::getConnexion();
    $query =$db->prepare($sql);
    
    try {
        $query->execute();
    }
    catch(Exception $e){
        die('Erreur: '.$e->getMessage());

    }
}
}

?>