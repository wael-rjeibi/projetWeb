<?php
include_once("C:/xampp/htdocs/noureddine/config.php");
include_once("C:/xampp/htdocs/noureddine/Model/traget.php");
class tragetC
{
    public function statistiques()
{
  
  $sql="select depart,count(*) from traget group by depart";
    
    $db = config::getConnexion();
    try{
        $liste = $db->query($sql);
        return $liste;
    }
    catch(Exception $e){
        die('Erreur: '.$e->getMessage());
    }
}
    function afficherTraget(){
        $sql="select * from traget";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
    }
    catch(Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
}
function afficherTragetTrie($selon){
    $sql="select * from traget order by ".$selon;
    $db = config::getConnexion();
    try{
        $liste = $db->query($sql);
        return $liste;
}
catch(Exception $e){
    echo 'Erreur: '.$e->getMessage();
}
}
function afficherTragetRech($rech,$selon){
    $sql="select * from Traget where ".$selon." like '$rech%'";
    $db = config::getConnexion();
    try{
        $liste = $db->query($sql);
        return $liste;
}
catch(Exception $e){
    echo 'Erreur: '.$e->getMessage();
}
}



public function ajouterTraget($traget){
    $sql="insert into Traget(libelle,depart,destination,temps) values(:libelle,:depart,:destination,:temps)";
    $db = config::getConnexion();
    try{
        $query=$db->prepare($sql);
        $query->execute([
        'libelle'=>$traget->getLibelle(),
        'depart'=>$traget->getDepart(),
        'destination'=>$traget->getDestination(),
        'temps'=>$traget->getTemps()
        
        ]);
        
    }
        catch(Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
}
public function ajouterCourse($traget,$proposition,$prix){
    $sql="insert into course(idTraget,idProposition,prix) values(:idTraget,:idProposition,:prix)";
    $db = config::getConnexion();
    try{
        $query=$db->prepare($sql);
        $query->execute([
        'idTraget'=>$traget,
        'idProposition'=>$proposition,
        'prix'=>$prix
        
        ]);
        
    }
        catch(Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
}



function modifierTraget($ref,$traget) {
    $sql="UPDATE  traget set libelle=:libelle,depart=:depart,destination=:destination,temps=:temps where ref=".$ref."";
    $db = config::getConnexion();
    try{
        $query = $db->prepare($sql);
    
        $query->execute([
            'libelle'=>$traget->getLibelle(),
            'depart'=>$traget->getDepart(),
            'destination'=>$traget->getDestination(),
            'temps'=>$traget->getTemps()
        ]);			
    }
    catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }		
  }
public function afficherTragetDetail(int $rech1)
    {
        $sql="select * from Traget where ref=".$rech1."";
        
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    public function supprimerTraget($ref)
    {
        $sql = "DELETE FROM Traget WHERE ref=".$ref;
        $db = config::getConnexion();
        $query =$db->prepare($sql);
        
        try {
            $query->execute();
        }
        catch(Exception $e){
            die('Erreur: '.$e->getMessage());
    
        }
    }

}

?>