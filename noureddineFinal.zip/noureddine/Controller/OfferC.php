<?php
include_once("../config.php");
include_once("../Model/offer.php");
class OfferC
{


    
    function showOffers(){
        $sql="select * from offers";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
    }
    catch(Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
}


public function ajouterOffer($offer){
    $sql="insert into offers(title,text,monthsValid,discountMultiplier,idClient) values(:title,:text,:monthsValid,:discountMultiplier,:idClient)";
    $db = config::getConnexion();
    try{   
        $query=$db->prepare($sql);
        $query->execute([
        'title'=>$offer->getTitle(),
        'text'=>$offer->getText(),
        'monthsValid'=>$offer->getMonths(),
        'discountMultiplier'=>$offer->getMultiplier(),
        'idClient'=>$offer->getIdClient()
        ]);
        
    }
    catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
}

public function showOfferDetail(int $rech1)
    {
        $sql="select * from offers where idOffer=".$rech1."";
        
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }



function modifierOffer($offer, $offerid) {
    $sql="UPDATE  offers set title=:title,text=:text,monthsValid=:monthsValid ,discountMultiplier=:discountMultiplier, idClient=:idClient where idOffer=".$offerid."";
    $db = config::getConnexion();
    try{
        $query = $db->prepare($sql);
    
        $query->execute([
        'title'=>$offer->getTitle(),
        'text'=>$offer->getText(),
        'monthsValid'=>$offer->getMonths(),
        'discountMultiplier'=>$offer->getMultiplier(),
        'idClient'=>$offer->getIdClient()
        ]);			
    }
    catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }		
  }



    
public function supprimerOffer($idOffer)
{
    $sql = "DELETE FROM offers WHERE idOffer=".$idOffer."";
    $db = config::getConnexion();
    $query =$db->prepare($sql);
    
    try {
        $query->execute();
    }
    catch(Exception $e){
        die('Erreur: '.$e->getMessage());

    }
}
function showOneOffer($idOffer)
    {        
                 $sql="SELECT * FROM offers WHERE idOffer=".$idOffer."";
                 $db = config::getConnexion();

               	try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	


    }
}

?>