<?php
 include_once '../Controller/OfferC.php';
 $co = new OfferC();
 if(isset($_GET['idOffer'])){
     $co->supprimerOffer($_GET['idOffer']);
 
    header('Location:backOffers.php');
    }

 ?>