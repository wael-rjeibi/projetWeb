
<?php
$userEmail=$_GET['idClient'];

$message="You have a New Discount check your dashboard";
$SMTP_Config= "";

if (mail($userEmail,"New Discount For you",$message)){
    echo "mail Sent Successfuly!";
}
?>