<link rel="stylesheet" href="style.css" type="text/css" media="all" />
<?php
 include_once '../Controller/OfferC.php';
 
 $co = new OfferC();
 if(isset($_GET['idOffer'])){
   $offerC = new OfferC();
   $listeC = $offerC->showOfferDetail($_GET['idOffer']);
 
 foreach($listeC as $offers){
 ?>
 <body>
<!--<link rel="stylesheet" href="css3/style.css" type="text/css" media="all" />-->


  <div class="shell">
    <!-- Logo + Top Nav -->
    <div idclient="top">
      <h1><a href="#">Antico</a></h1>
  </div>
   <form action="#" method="post">
   <!-- Box -->
   <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>Add New Offer</h2>
          </div>
          <!-- End Box Head -->
            <!-- Form -->
            <div class="form">
              <p> 
                <label>idClient </label>
                <input type="number" class="field size1" name="idClient" value=<?php echo $offers['idClient'];?> />
              </p>
             
              <p> 
                <label>title </label>
                <input type="text" class="field size1" name="title" value=<?php echo $offers['title'];?> />
              </p>
              
              <p> 
                <label>Text </label>
                <input type="text" class="field size1" name="text" value=<?php echo $offers['text'];?> />
              </p>
              <p> 
                <label>discount Multiplier </label>
                <input type="number" step="0.01" class="field size1" name="discountMultiplier" value=<?php echo $offers['discountMultiplier'];?> />
              </p>
              <p> 
                <label>Months Valid </label>
                <input type="number" class="field size1" name="monthsValid" value=<?php echo $offers['monthsValid'];}?> />
              </p>

             

             
            </div>
            <!-- End Form -->
            <!-- Form Buttons -->
            <div class="buttons">
              <input type="Reset" class="button" value="Reset" />
              <input type="submit" class="button" value="submit" />
            </div>
            <!-- End Form Buttons -->
          </form>
 </div>
 </div>
 <?php
 // create event
 $offers = null;

 // create an instance of the controller

 $offersC = new offerC();
 if ( isset($_POST["idClient"])) {
     
         $offers = new offer(
             $_POST['idClient'],
             $_POST['discountMultiplier'],
             $_POST['title'],
             $_POST['text'],
             $_POST['monthsValid']
         );
        $offersC->modifierOffer($offers,$_GET['idOffer']);
         echo $_GET['idOffer'];
         header('Location:backOffers.php');
     }
     

 
}

?>