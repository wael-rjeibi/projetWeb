
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste maps</title>
</head>
<body>
    <center>
    <?php
    include_once '../Model/map.php';
    include_once '../Controller/mapC.php';
    $mapC = new mapC();
    $liste=$mapC->afficherMap();
    
    foreach($liste as $map)
    {?>
    <h2>Nom : <?php echo $map['nom'];  ?></h2>
    <iframe src="https://www.google.com/maps/embed?pb=<?php echo $map['lien'];  ?>" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      
<?php
 }?>

</center>
</body>
</html>
