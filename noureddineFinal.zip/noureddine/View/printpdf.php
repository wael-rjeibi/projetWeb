<?php
require('fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,$_POST['title']);
$pdf->Cell(72,26,$_POST['text']);
$pdf->Cell(104,58,$_POST['discount']);
$pdf->Output();
?>