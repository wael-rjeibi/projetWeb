<?php

include_once '../Model/offer.php';
include_once '../Controller/OfferC.php';
$offerC = new offerC();
$listeC = $offerC->showOffers();

$offerC = new offerC();
if (
    isset($_POST["idClient"])
) {

        $offer = new Offer(
            ($_POST["idClient"]),
            ($_POST["discountMultiplier"]),
            ($_POST["title"]), 
            ($_POST["texte"]),
            ($_POST["monthsValid"]),
        );
        $offerC->ajouterOffer($offer);
        
        echo "success";
    
   
}

?>
