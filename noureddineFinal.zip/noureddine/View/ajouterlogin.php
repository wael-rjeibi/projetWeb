<?php
    include_once '../Model/clients.php';
    include_once '../Controller/clientsC.php';

    $error = "";

    // create adherent
    $clients = null;

    // create an instance of the controller
    $clientsC = new clientsC();
    if (
       
		isset($_POST["cin"]) &&		
        isset($_POST["nom"]) &&
		isset($_POST["prenom"]) && 
        isset($_POST["adresse"]) && 
        isset($_POST["destination"])
    ) {
        if (
            
			!empty($_POST['cin']) &&
            !empty($_POST["nom"]) && 
			!empty($_POST["prenom"]) && 
            !empty($_POST["adresse"]) && 
            !empty($_POST["destination"])
        ) {
            $clients = new clients(
              
				$_POST['cin'],
                $_POST['nom'], 
				$_POST['prenom'],
                $_POST['adresse'],
                $_POST['destination']
            );
            $clientsC->ajouterlogin($clients);
            header('Location:welcome.php');
        }
        else
            $error = "Missing information";
    }
          
           
      
      
    
   

    
?>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel='stylesheet'href='ajouterlogin.css'>

</head>
    <body>
    
        
        
        <div id="error">
            <?php echo $error; ?>
        </div>
        
        <form action="" method="POST">
            <table border="1" align="center">
                
				<tr>
                    <td>
                        <label for="cin">cin:
                        </label>
                    </td>
                    <td><input type="text" name="cin" id="cin" maxlength="8" minlength="8" required></td>
                </tr>
                <tr>
                    <td>
                        <label for="nom">nom:
                        </label>
                    </td>
                    <td><input type="text" name="nom" id="nom" maxlength="20" required></td>
                </tr>
                <tr>
                    <td>
                        <label for="prenom">prenom:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="prenom" id="prenom">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="adresse">Adresse :
                        </label>
                    </td>
                    <td>
                        <input type="adresse" name="adresse" id="adresse" required>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="destination">destination:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="destination" id="destination"  required>
                    </td>
                </tr>              
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Sign-up" type="button" class="btn btn-success btn-rounded"> 
                    </td>
                    <td>
                        <input type="reset" value="Cancel" type="button" class="btn btn-danger btn-rounded">
                    </td>
                </tr>
            </table>
        </form>
        <video autoplay muted loop id="myVideo">
        <source src="sun.mp4" type="video/mp4">
      </video>
      
    </body>
   
		
</html>