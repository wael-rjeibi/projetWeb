<link rel="stylesheet" href="style.css" type="text/css" media="all" />
<?php
 include_once '../../../Controller/voitureC.php';
 include_once '../../../Model/voiture.php';
 
 $co = new voitureC();
 if(isset($_GET['idv'])){
   $voitureC = new voitureC();
   $listeC = $voitureC->afficherVoitureDetail($_GET['idv']);
 
 foreach($listeC as $voiture){
 ?>
 <body>
<!--<link rel="stylesheet" href="css3/style.css" type="text/css" media="all" />-->


  <div class="shell">
    <!-- Logo + Top Nav -->
    <div id="top">
      <h1><a href="#">Antico</a></h1>
  </div>
   <form action="#" method="post">
   <!-- Box -->
   <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>Add New Event</h2>
          </div>
          <!-- End Box Head -->
            <!-- Form -->
            <div class="form">
              <p> 
                <label>Marque </label>
                <input type="text" class="field size1" name="marque" value=<?php echo $voiture['marque'];?> />
              </p>
             
              <p> 
                <label>Matricule </label>
                <input type="text" class="field size1" name="matricule" value=<?php echo $voiture['matricule'];?> />
              </p>
              
            
              <p> 
                <label>Image </label>
                <input type="file" class="field size1" name="image" value=<?php echo $voiture['image'];}?> />
              </p>

             

             
            </div>
            <!-- End Form -->
            <!-- Form Buttons -->
            <div class="buttons">
              <input type="Reset" class="button" value="Reset" />
              <input type="submit" class="button" value="submit" />
            </div>
            <!-- End Form Buttons -->
          </form>
 </div>
 </div>
 <?php
 // create event
 $voiture = null;

 // create an instance of the controller

 $voitureC = new voitureC();
 if (
     isset($_POST["marque"]) && 
     isset($_POST["matricule"]) &&
     isset($_POST["image"])
 ) {
     if (
         !empty($_POST["marque"]) && 
         !empty($_POST["matricule"]) &&
         !empty($_POST["image"]) 
     ) {
         $voiture = new voiture(
             $_POST['marque'],
             $_POST['matricule'],
             $_POST['image']
         );
        $voitureC->modifierVoiture($_GET['idv'],$voiture);
         
         header('Location:backVoiture.php');
     }
     else
         $error = "Missing information";
 }

 
}

?>