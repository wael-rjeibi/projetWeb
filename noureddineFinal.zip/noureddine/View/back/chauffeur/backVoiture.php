<?php

include_once '../../../Model/voiture.php';
include_once '../../../Controller/voitureC.php';
$voitureC = new voitureC();
$listeC = $voitureC->afficherVoiture();

$voitureC = new voitureC();
if (
    isset($_POST["marque"]) && 
    isset($_POST["matricule"]) &&
    isset($_POST["image"])
) {
    if (
        !empty($_POST["marque"]) && 
        !empty($_POST["matricule"]) &&
        !empty($_POST["image"])
    ) {
        $voiture = new voiture(
            $_POST['marque'],
            $_POST['matricule'],
            $_POST['image']
        );
        $voitureC->ajouterVoiture($voiture);
        
        header('Location:backVoiture.php');
    }
    else
        $error = "Missing information";
}

?>


<link rel="stylesheet" href="style.css" type="text/css" media="all" />

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Waslny</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />


</head>
<script src="js/saisie.js"></script>
<body>
<!--<link rel="stylesheet" href="css3/style.css" type="text/css" media="all" />-->
<!-- Header -->
<div id="header">
  <div class="shell">
    <!-- Logo + Top Nav -->
    <div id="top">
      <h1><a href="#">Waslny</a></h1>
      <div id="top-navigation"> </a> </span> <a href="logout.php">Log out</a> </div>
    </div>
    <!-- End Logo + Top Nav -->
    <!-- Main Nav -->
    <div id="navigation">
    <ul>
        <li><a href="../../backClients.php" class="active"><span>Gestion Clients</span></a></li>
       
        <li><a href="../../backDiagnostic.php" class="active"><span>Gestion diagnostics</span></a></li>
        <li><a href="../../listMap.php" class="active"><span>Gestion maps</span></a></li>

        <li><a href="backChauffeur.php" class="active"><span>Gestion Chauffeurs</span></a></li>
        <li><a href="backVoiture.php" class="active"><span>Gestion voitures</span></a></li>

        <li><a href="../backTraget.php" class="active"><span>Gestion tragets</span></a></li>
        <li><a href="../backProposition.php" class="active"><span>Gestion propositions</span></a></li>
      
      </ul>
    </div>
    <!-- End Main Nav -->
  </div>
</div>
<!-- End Header -->
<!-- Container -->
<div id="container">
  <div class="shell">
    <!-- Small Nav -->
    <div class="small-nav"> <a href="#">voiture</a> <span>&gt;</span> voiture </div>
    <!-- End Small Nav -->
    <!-- Message OK -->
    
    <!-- End Message OK -->
    <!-- Message Error -->
    
    <!-- End Message Error -->
    <br />
    <!-- Main -->
    <div id="main">
      <div class="cl">&nbsp;</div>
      <!-- Content -->
      <div id="content">
        <!-- Box -->
       
          <!-- Box Head -->
          <div class="box-head">
            <h2 class="left">voiture</h2>
            <div class="right">
            
            </div>
          </div>
          
          <!-- End Box Head -->
          <!-- Table -->
          <div class="table">
          
            <table width="100%" border="0" cellspacing="0" cellpadding="0" >
        
              <tr>
               
                <th>IDv</th>
                <th>Marque</th>
            
                <th>Matricule</th>
                
            
            
            <th>Image</th>
              
               
              </tr>

              

              <?php
    foreach($listeC as $voiture){
        ?>


              <tr>
                <td><?php echo $voiture['idv']; ?></td>
                <td><?php echo $voiture['marque']; ?></td>
                 
                <td><?php echo $voiture['matricule']; ?></td>
                <td><img  src="../../front/chauffeurs/images/<?php echo $voiture['image']; ?>"width="50" height="60">
</td>
               
                <td><a href="supprimerVoiture.php?idv=<?php echo $voiture['idv']; ?>" class="ico del">Delete</a> </td>
                <td> <a href="modifierVoiture.php?idv=<?php echo $voiture['idv']; ?>" class="ico edit">Edit</a>
               
              
              
              
              </td>
              </tr>
              <?php } ?>
              
              
              
              
              
              
            
           
            </table>
            <!-- End Pagging -->
          </div>
          <!-- Table -->
      
        <!-- End Box -->
        <!-- Box -->
        <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>voiture</h2>
          </div>
          <!-- End Box Head -->
          <form action="#" method="post">
            <!-- Form -->
            <div class="form">
              <p> 
                <label>Marque </label>
                <input type="text" class="field size1" name="marque" idv="marque"/>
              </p>
              

              <p> 
                <label>Matricule </label>
                <input type="text" class="field size1" name="matricule" idv="matricule" />
              </p>
              

              <p> 
                <label>Image </label>
                <input type="file" class="field size1" name="image" idv="image" />
              </p>
            </div>
            <!-- End Form -->
            <!-- Form Buttons -->
            <div class="buttons">
              <input type="Reset" class="button" value="Reset" />
              <input type="submit" class="button" value="submit" onclick="verif();"/>
            </div>
            <!-- End Form Buttons -->
          </form>
        </div>
        <!-- End Box -->
      </div>
      <!-- End Content -->
      <!-- Sidebar -->
      <div id="sidebar">
        <!-- Box -->
        <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>Voiture</h2>
          </div>
          <!-- End Box Head-->
          <div class="box-content"> <a href="#" class="add-button"><span>voiture</span></a>
            <div class="cl">&nbsp;</div>
            <p class="select-all">
              <input type="checkbox" class="checkbox" />
              <label>select all</label>
            </p>
            <p><a href="#">Delete Selected</a></p>
           
          </div>
        </div>
        <!-- End Box -->
      </div>
      <!-- End Sidebar -->
      <div class="cl">&nbsp;</div>
    </div>
    <div id="piechart"> </div>
    <!-- Main -->
  </div>
</div>



<!-- End Container -->
<!-- Footer -->
<div id="footer">
  <div class="shell"> <span class="left">&copy; 2010 - CompanyName</span> <span class="right"> Design by <a href="http://chocotemplates.com">Chocotemplates.com</a> </span> </div>
</div>
<!-- End Footer -->





</body>
</html>
