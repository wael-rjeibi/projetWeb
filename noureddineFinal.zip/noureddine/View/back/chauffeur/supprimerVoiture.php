<?php
 include_once '../../../Controller/voitureC.php';
 $co = new voitureC();
 if(isset($_GET['idv'])){
     $co->supprimerVoiture($_GET['idv']);
 
    header('Location:backVoiture.php');
    }

 ?>