<?php
 include_once '../../Controller/propositionC.php';
 $co = new propositionC();
 if(isset($_GET['id'])){
     $co->supprimerProposition($_GET['id']);
 
    header('Location:backProposition.php');
    }

 ?>