<?php

include_once '../Model/offer.php';
include_once '../Controller/OfferC.php';
$offerC = new offerC();
$listeC = $offerC->showOffers();

$offerC = new offerC();
if (
    isset($_POST["idClient"])
) {

        $offer = new Offer(
            ($_POST["idClient"]),
            ($_POST["discountMultiplier"]),
            ($_POST["title"]), 
            ($_POST["texte"]),
            ($_POST["monthsValid"]),
        );
        $offerC->ajouterOffer($offer);
        
        header('Location:backOffers.php');
    
   
}

?>


<link rel="stylesheet" href="style.css" type="text/css" media="all" />

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>SpringTime</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />


</head>
<script src="front/js/saisie.js"></script>

<body>
<!--<link rel="stylesheet" href="css3/style.css" type="text/css" media="all" />-->
<!-- Header -->
<div id ="header"> 
  <div class="shell"> 
    <!-- Logo + Top Nav -->
    <div id="top">
      <h1><a href="#">waselny</a></h1>
      <div id="top-navigation"> </a> </span> <a href="logout.php">Log out</a> </div>
      <form action="" method="POST" class="search-form">
                <input type="text" name="search" id="search" placeholder="search" style="background:#1fe0ff;">
					<button type="submit" class="searchButton" name="submit">search</button>
				</form>



    </div>
    <!-- End Logo + Top Nav -->
    <!-- Main Nav -->
    <div id="navigation">
      <ul>
      <li><a href="backClients.php" class="active"><span>Gestion clients</span></a></li>
       
       <li><a href="backOffers.php" class="active"><span>Gestion offres</span></a></li>
      
      </ul>
    </div>
    <!-- End Main Nav -->
  </div>
</div>
<!-- End Header -->
<!-- Container -->
<div id="container">
  <div class="shell">
    <!-- Small Nav -->
    <div class="small-nav"> <a href="#">Dashboard</a> <span>&gt;</span> Current Offers </div>
    <!-- End Small Nav -->
    <!-- Message OK -->
    
    <!-- End Message OK -->
    <!-- Message Error -->
    
    <!-- End Message Error -->
    <br />
    <!-- Main -->
    <div id="main">
      <div class="cl">&nbsp;</div>
      <!-- Content -->
      <div id="content">
        <!-- Box -->
       
          <!-- Box Head -->
          <div class="box-head">
            <h2 class="left">Current Offers</h2>
            <div class="right">
            
            </div>
          </div>
          
          <!-- End Box Head -->
          <!-- Table -->
          <div class="table">
          
            <table width="100%" border="0" cellspacing="0" cellpadding="0" >
        
              <tr>
               
                <th>IdClients</th>
                <th>Discount</th>
            
                <th>title</th>
                <th>text</th>
            
            <th>Months</th>
              
               
              </tr>

              

              <?php
    foreach($listeC as $offers){
        ?>


              <tr>
                <td><?php echo $offers['idClient']; ?></td>
                <td><?php echo $offers['discountMultiplier']; ?></td>
                 
                <td><?php echo $offers['title']; ?></td>
                <td><?php echo $offers['text']; ?></td>  
                <td><?php echo $offers['monthsValid']; ?></td>  
                <td><form action="printpdf.php" method="POST">
                              
                <input type="hidden" name="discount" value="<?=$offers['discountMultiplier']?>" >
                <input type="hidden" name="text" value="<?=$offers['text']?>" >
                <input class="btn btn-danger" type="submit" name="submit1" value="Print PDF">
                              <input type="hidden" name="title" value="<?=$offers['title']?>">
                          </form>

                </td>
</td>
               
                <td><a href="supprimerOffers.php?idOffer=<?php echo $offers['idOffer']; ?>" class="ico del">Del</a> </td>
                <td> <a href="editOffer.php?idOffer=<?php echo $offers['idOffer']; ?>" class="ico edit">Edit</a>
                <td><a href="mail.php?idClient=<?php echo $offers['idClient']; ?>" class="ico del">Mail</a> </td>

               
              
              
              
              </td>
              </tr>
              <?php } ?>
              
              
              
              
              
              
            
           
            </table>
            <!-- End Pagging -->
          </div>
          <!-- Table -->
      
        <!-- End Box -->
        <!-- Box -->
        <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>Add New Offer</h2>
          </div>
          <!-- End Box Head -->
          <form action="#" method="post">
            <!-- Form -->
            <div class="form">
              <p> 
                <label>Id Client </label>
                <input type="number" class="field size1" name="idClient" idClient="idClient"/>
              </p>
              

              <p> 
                <label>Discount Multiplier </label>
                <input type="number" step="0.01" class="field size1" name="discountMultiplier" idClient="discountMultiplier" />
              </p>
              

              <p> 
                <label>Title </label>
                <input type="texte" class="field size1" name="title" idClient="title" />
              </p>
              <p> 
                <label>Texte </label>
                <input type="texte" class="field size1" name="texte" idclient="texte" />
              </p>
              <p> 
                <label>Months Valid </label>
                <input type="number" class="field size1" name="monthsValid" idclient="monthsValid" />
              </p>
            </div>
            <!-- End Form -->
            <!-- Form Buttons -->
            <div class="buttons">
              <input type="Reset" class="button" value="Reset" />
              <input type="submit" class="button" value="submit"/>
            </div>
            <!-- End Form Buttons -->
          </form>
        </div>
        <!-- End Box -->
      </div>
      <!-- End Content -->
      <!-- Sidebar -->
      <div id="sidebar">
        <!-- Box -->
        <div class="box">
          <!-- Box Head -->
          <div class="box-head">
            <h2>Management</h2>
          </div>
          <!-- End Box Head-->
          <div class="box-content"> <a href="#" class="add-button"><span>Add new Offer</span></a>
            <div class="cl">&nbsp;</div>
            <p class="select-all">
            <div class="sort">
              <form method="POST"><label></label>
              <select name="tri" class="field" >
              <option value="idClient">Id Client</option>
              <option value="discountMultiplier">Discount Multiplier</option>
              <option value="title">title</option>
                
              </select><input type="submit"  value="trier"></form>
              
            </div>
    </p>
           
          </div>
        </div>
       
        <!-- End Box -->
      </div>
      <!-- End Sidebar -->
      <div class="cl">&nbsp;</div>
    </div>
    <div id="piechart"> </div>
    <!-- Main -->
  </div>
</div>

<?php 
include_once "../Controller/clientsC.php";
$clientsC = new clientsC();

$listeC = $clientsC->statistiques();
 ?>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
    
  var data = google.visualization.arrayToDataTable([
   
  [ 'adresse', 'nom'],
  

  <?php
 
 foreach($listeC as $k){
  echo "["; echo "'";echo $k['adresse'];echo"'";echo",";echo $k['count(*)'];echo"],";}?>


 

 
]);

 // Optional; add a title and set the width and height of the chart
 var options = {'title':'ADRESSE', 'width':750, 'height':400};

 var chart = new google.visualization.PieChart(document.getElementById('piechart'));
 chart.draw(data, options);
}
</script>



<!-- End Container -->
<!-- Footer -->
<div id="footer">
  <div class="shell"> <span class="left">&copy; 2010 - CompanyName</span> <span class="right"> Design by <a href="http://chocotemplates.com">Chocotemplates.com</a> </span> </div>
</div>
<!-- End Footer -->







</body>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div id="google_translate_element"></div>
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');

    }
    </script>
</html>
