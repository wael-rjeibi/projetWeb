<?php
class proposition{
    private ?int $ref = null;
    private ?string $nom = null;
    private ?float $pourcentage = null;
    function __construct(string $nom,string $pourcentage)
    {
        
        $this->nom=$nom;
        $this->pourcentage=$pourcentage;
    }
    function getRef(): int{
        return $this->ref;
    }
    function getNom(): string{
        return $this->nom;
    }
   
    function getPourcentage(): float{
        return $this->pourcentage;
    }

    function setNom(string $nom): void{
        $this->nom=$nom;
    }
    function setPourcentage(float $pourcentage): void{
        $this->pourcentage=$pourcentage;
    }
    
  
 
   
}
?>