<?php
class map{
    private ?int $id = null;
    private ?string $lien = null;
    private ?string $nom = null;
    function __construct(string $lien,string $nom)
    {
        
        $this->lien=$lien;
        $this->nom=$nom;
    }
    function getId(): int{
        return $this->id;
    }
   
    function getLien(): string{
        return $this->lien;
    }
    
    function getNom(): string{
        return $this->nom;
    }
    
   
}
?>