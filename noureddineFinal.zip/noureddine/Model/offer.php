<?php
class Offer{
    private ?int $idOffer = null;
    private ?int $idClient = null;
    private ?float $discountMultiplier = null;
    private ?string $title = null;
    private ?string $text = null;
    private ?int $monthsValid = null; 


    function __construct(int $idClient,float $discountMultiplier,string $title,string $text, int $monthsValid)
    {
        $this->idClient=$idClient;
        $this->discountMultiplier=$discountMultiplier;
        $this->title=$title;
        $this->text=$text;
        $this->monthsValid=$monthsValid;
    }
     
    
    function getIdClient(): int{
        return $this->idClient;
    }
    function getIdOffer(): int{
        return $this->idOffer;
    }
   
    function getTitle(): string{
        return $this->title;
    }
    
    function getText(): string{
        return $this->text;
    }
    function getMultiplier(): int{
        return $this->discountMultiplier;
    }
    function getMonths(): int{
        return $this->monthsValid;
    }


    function setTitle(string $title): void{
        $this->title=$title;
    }

    function setText(string $title): void{
        $this->text=$text;
    }

    function setMultiplier(float $multiplier): void{
        $this->discountMultiplier=$multiplier;
    }

    function setMonthsValid(int $months): void{
        $this->months=$months;
    }
}
?>

