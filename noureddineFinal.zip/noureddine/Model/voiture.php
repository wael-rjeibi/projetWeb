<?php
class voiture{
    private ?int $idv = null;
    private ?string $marque = null;
    private ?string $matricule = null;
    private ?string $image = null;
    function __construct(string $marque,string $matricule,string $image)
    {
        
        $this->marque=$marque;
        $this->matricule=$matricule;
        $this->image=$image;
    }
    function getIdv(): int{
        return $this->idv;
    }
    function getMarque(): string{
        return $this->marque;
    }
   
    function getMatricule(): string{
        return $this->matricule;
    }
    
    function getImage(): string{
        return $this->image;
    }
    function setMarque(string $marque): void{
        $this->marque=$marque;
    }
    
    function setMatricule(string $matricule): void{
        $this->matricule=$matricule;
    }
   
   
}
?>